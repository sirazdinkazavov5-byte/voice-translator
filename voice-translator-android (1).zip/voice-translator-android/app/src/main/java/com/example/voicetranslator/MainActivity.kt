package com.example.voicetranslator

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

class MainActivity : AppCompatActivity(), RecognitionListener {

    private lateinit var btn: Button
    private lateinit var status: TextView
    private lateinit var ruText: TextView
    private lateinit var enText: TextView
    private lateinit var translateSwitch: Switch

    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null
    private var translator: Translator? = null
    private var translatorReady = false

    // Накопленный текст: всё, что уже финализировано (после паузы)
    private val ruDone = StringBuilder()
    private val enDone = StringBuilder()

    private val requestAudio = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn = findViewById(R.id.btn)
        status = findViewById(R.id.status)
        ruText = findViewById(R.id.ruText)
        enText = findViewById(R.id.enText)
        translateSwitch = findViewById(R.id.translateSwitch)

        setupTranslator()
        loadSpeechModel()

        btn.setOnClickListener {
            if (speechService == null) startListening() else stopListening()
        }
    }

    private fun loadSpeechModel() {
        status.text = "Загрузка модели распознавания..."
        // Папка assets/model-ru копируется в память телефона при первом запуске
        StorageService.unpack(this, "model-ru", "model",
            { model: Model ->
                recognizer = Recognizer(model, 16000.0f)
                runOnUiThread {
                    btn.isEnabled = true
                    btn.text = "Начать"
                    status.text = "Готов"
                }
            },
            { e: java.io.IOException ->
                runOnUiThread { status.text = "Ошибка модели: ${e.message}" }
            })
    }

    private fun setupTranslator() {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.RUSSIAN)
            .setTargetLanguage(TranslateLanguage.ENGLISH)
            .build()
        translator = Translation.getClient(options)
        // Модель перевода скачивается один раз (нужен интернет), дальше работает офлайн
        translator?.downloadModelIfNeeded(DownloadConditions.Builder().build())
            ?.addOnSuccessListener { translatorReady = true }
            ?.addOnFailureListener {
                runOnUiThread { status.text = "Не скачана модель перевода (нужен интернет один раз)" }
            }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val rec = recognizer ?: return
        speechService = SpeechService(rec, 16000.0f).also { it.startListening(this) }
        btn.text = "Остановить"
        status.text = "Слушаю... говорите"
    }

    private fun stopListening() {
        // После stop() Vosk отдаст последний кусок через onFinalResult
        speechService?.stop()
        speechService = null
        btn.text = "Начать"
        status.text = "Завершаю..."
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == requestAudio) {
            Toast.makeText(this, "Нужен доступ к микрофону", Toast.LENGTH_LONG).show()
        }
    }

    // --- Колбэки Vosk (приходят во время разговора) ---

    // Частичный текст: показывается сразу, пока вы говорите (это и есть «живой» перевод)
    override fun onPartialResult(hypothesis: String?) {
        val partial = JSONObject(hypothesis ?: "{}").optString("partial")
        runOnUiThread {
            ruText.text = ruDone.toString() + partial
        }
    }

    // Фраза закончилась (пауза): фиксируем и переводим
    override fun onResult(hypothesis: String?) {
        handleFinalPhrase(hypothesis)
    }

    // Пришло после stop(): последний кусок речи
    override fun onFinalResult(hypothesis: String?) {
        handleFinalPhrase(hypothesis)
        runOnUiThread {
            btn.text = "Начать"
            status.text = "Готов"
        }
    }

    override fun onError(exception: Exception?) {
        runOnUiThread { status.text = "Ошибка: ${exception?.message}" }
        stopListening()
    }

    override fun onTimeout() {
        stopListening()
    }

    private fun handleFinalPhrase(hypothesis: String?) {
        val text = JSONObject(hypothesis ?: "{}").optString("text").trim()
        if (text.isEmpty()) return

        ruDone.append(text).append(' ')
        runOnUiThread { ruText.text = ruDone.toString() }

        if (!translateSwitch.isChecked) return
        val t = translator ?: return
        if (!translatorReady) {
            runOnUiThread { status.text = "Модель перевода ещё не готова" }
            return
        }
        t.translate(text)
            .addOnSuccessListener { en ->
                enDone.append(en).append(' ')
                runOnUiThread { enText.text = enDone.toString() }
            }
            .addOnFailureListener { e ->
                runOnUiThread { status.text = "Ошибка перевода: ${e.message}" }
            }
    }

    override fun onDestroy() {
        speechService?.shutdown()
        recognizer?.close()
        translator?.close()
        super.onDestroy()
    }
}
